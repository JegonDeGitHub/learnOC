//
//  Bird.h
//  Zoo v1.1
//
//  Created by apple on 2019/5/7.
//  Copyright © 2019年 apple. All rights reserved.
//

#import "Animal.h"

@interface Bird : Animal
-(void)fly;
-(NSString*)description;
-(void)shout;
@end
