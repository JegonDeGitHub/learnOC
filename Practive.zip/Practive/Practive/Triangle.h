//
//  Triangle.h
//  Practive
//
//  Created by apple on 2019/5/7.
//  Copyright © 2019年 apple. All rights reserved.
//

#import "shape.h"

@interface Triangle : shape
-(float)getArea;
//-(float)getPerimeter;
@end
