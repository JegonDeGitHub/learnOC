//
//  Square.m
//  Practive
//
//  Created by apple on 2019/5/7.
//  Copyright © 2019年 apple. All rights reserved.
//

#import "Square.h"

@implementation Square
-(float)getArea {
    return _weight*_height;
}
-(float)getPerimeter {
    return _weight*4;
}
@end
