//
//  Parallelogram.h
//  Practive
//
//  Created by apple on 2019/5/7.
//  Copyright © 2019年 apple. All rights reserved.
//

#import "Rectangle.h"

@interface Parallelogram : Rectangle

@end
