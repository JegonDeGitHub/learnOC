//
//  main.m
//  zoo
//
//  Created by apple on 2019/5/7.
//  Copyright © 2019年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Dog.h"
int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Dog* d = [[Dog alloc]initWithWeight:27 Height:107];
        NSLog([d description]);
        
    }
    return 0;
}
