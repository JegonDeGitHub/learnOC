//
//  MKJCollectionViewCell.h
//  PhotoAnimationScrollDemo
//
//  Created by MKJING on 16/8/9.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MKJCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *heroImageVIew;
@property (weak, nonatomic) IBOutlet UIView *backView;

@end
