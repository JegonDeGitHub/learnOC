//
//  MKJConstant.m
//  PhotoAnimationScrollDemo
//
//  Created by MKJING on 16/8/10.
//  Copyright © 2016年 MKJING. All rights reserved.
//

#import "MKJConstant.h"


const CGFloat MKJLineSpacing = 40.f;
const CGFloat MKJZoomScale = 1.45f;
const CGFloat MKJMinZoomScale = MKJZoomScale - 1.0f;