//
//  ViewController.m
//  Demo
//
//  Created by apple on 2019/6/3.
//  Copyright © 2019年 apple. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

/*方法类型 （返回值类型）函数名：（参数类型 *）参数名 {
 函数体;
 }*/

/**/
- (void)viewDidLoad {//视图已加载后（系统自动执行的操作）
    [super viewDidLoad];
    
    //该函数相当于C语言里面的main()
    // Do any additional setup after loading the view, typically from a nib.
    //创建一个相框
    UIImageView *bgImageView = [[UIImageView alloc]init];
    
    //给相框设置大小（左上角作为点）
    bgImageView.frame = CGRectMake(0, 0, 320, 640);
    
    //给相框添加图片
    bgImageView.image = [UIImage imageNamed:@"Background.png"];
    
    //将相框添加到视图上 ()
    [self.view addSubview:bgImageView];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
